import Foundation

public struct Chip {
    public enum ChipType: UInt32 {
        case small = 1
        case medium
        case big
    }
    
    public let chipType: ChipType
    
    public static func make() -> Chip {
        guard let chipType = Chip.ChipType(rawValue: UInt32(arc4random_uniform(3) + 1)) else {
            fatalError("Incorrect random value")
        }
        return Chip(chipType: chipType)
    }
    
    public func sodering() {
        let soderingTime = chipType.rawValue
        sleep(UInt32(soderingTime))
    }
}

class ChipStorage {
    private var count = 0
    public var isAvailable = false
    private var chips = [Chip]()
    private let condition = NSCondition()
    
    public var isEmpty: Bool {
        return chips.isEmpty
    }
    
    func push(chip: Chip) {
        condition.lock()
        chips.append(chip)
        count += 1
        print("Микросхема \(count) добавлена в хранилище")
        isAvailable = true
        condition.signal()
        condition.unlock()
    }
    
    func pop() -> Chip {
        
        while (!isAvailable) {
            condition.wait()
            print("Ждем микросхему")
        }
        
        let chip = chips.removeLast()
        print("Забираем микросхему на припайку")
        condition.signal()
        condition.unlock()
        
        if isEmpty {
            isAvailable = false
        }
        return chip
    }
}

class ChipProducerThread: Thread {
    let storage: ChipStorage
    
    init(storage: ChipStorage) {
        self.storage = storage
    }
    
    override func main() {
        let loop = RunLoop.current
        
        Timer.scheduledTimer(withTimeInterval: 2, repeats: true) { [weak self] _ in
            guard let self = self else { return }
            let chip = Chip.make()
            self.storage.push(chip: chip)
        }

        loop.run(until: Date(timeIntervalSinceNow: 20))
    }
}

class ChipWorkerThread: Thread {
    let storage: ChipStorage
    
    init(storage: ChipStorage) {
        self.storage = storage
    }
    
    override func main() {
        repeat {
            let storageChip = storage.pop()
            storageChip.sodering()
            print("Припаиваем микросхему")
        } while storage.isAvailable || storage.isEmpty
    }
}


let storage = ChipStorage()
let producerThread = ChipProducerThread(storage: storage)
let workerThread = ChipWorkerThread(storage: storage)

producerThread.start()
workerThread.start()

